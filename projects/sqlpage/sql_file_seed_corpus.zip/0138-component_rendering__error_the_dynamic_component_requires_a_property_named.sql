
select 'dynamic' as component; -- missing "properties" column